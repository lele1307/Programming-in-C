void test(void);
void PROG_EXTEN(Program *p,ProgramArr progarr);
void INSTRS_EXTEN(Program *p,ProgramArr progarr);
void INSTRUCT_EXTEN(Program *p,ProgramArr progarr);
void READFILE_EXTEN(Program *p,ProgramArr progarr);
void IFCOND_EXTEN(Program *p,ProgramArr progarr);
void IFGREATER_EXTEN(Program *p,ProgramArr progarr);
void IFEQUAL_EXTEN(Program *p,ProgramArr progarr);

void LOOP(Program *p,ProgramArr progarr);
void NUM(Program *p,ProgramArr progarr);
int LOOP_REC(Program *p);
void LOOP_INTE(Program *p,ProgramArr progarr);
void BREAK(Program *p,ProgramArr progarr);
